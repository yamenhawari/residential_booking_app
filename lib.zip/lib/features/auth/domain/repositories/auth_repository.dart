import 'package:dartz/dartz.dart';
import 'package:residential_booking_app/core/entities/user.dart';
import '../../../../core/error/failures.dart';
import '../usecases/login_usecase.dart';
import '../usecases/register_usecase.dart';

abstract class AuthRepository {
  Future<Either<Failure, Unit>> register(RegisterParams params);

  Future<Either<Failure, User>> login(LoginParams params);

  Future<Either<Failure, Unit>> logout();

  Future<Either<Failure, User>> getCurrentUser();
}
