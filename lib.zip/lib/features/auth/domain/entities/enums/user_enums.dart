enum UserRole { owner, tenant }

enum UserStatus { active, pending, blocked, unknown }
