class PriceConstants {
  static const double minPrice = 0;
  static const double maxPrice = 10000;

  static const double exchangeRateSYP = 12000;
}
